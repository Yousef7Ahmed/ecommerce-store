const express = require("express")
const router = express.Router()
const authMiddleware = require("../middlewares/authMiddleware")
const checkRole = require("../middlewares/checkRole")
const validate = require("../middlewares/validate")
const {
    getAllProducts,
    getProduct,
    createProduct,
    updateProduct,
    deleteProduct,
    deleteProductImage,
} = require("../controllers/productController");

const {createProductSchema, updateProductSchema} = require("../validators/product.validator")
const {objectIdSchema} = require("../validators/common.validator")
const upload = require("../middlewares/uploadMiddleware")

router.route("/")
    .get(getAllProducts)
    .post(
        authMiddleware,
        checkRole(["ADMIN", "MANAGER"]),
        upload.array("images", 10),
        validate(createProductSchema),
        createProduct
    )
    
router.route("/:id")
            .get(validate(objectIdSchema, "params"),getProduct)
            .put(
                validate(objectIdSchema, "params"),
                authMiddleware,
                checkRole(["ADMIN", "MANAGER"]),
                upload.array("images", 10),
                validate(updateProductSchema),
                updateProduct
            )
            .delete(validate(objectIdSchema, "params"),authMiddleware, checkRole(["ADMIN"]), deleteProduct)

router.delete(
    "/:id/images/:imageIndex",
    authMiddleware,
    checkRole(["ADMIN", "MANAGER"]),
    deleteProductImage
);

module.exports = router
